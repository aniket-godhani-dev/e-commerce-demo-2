import React, { useState } from 'react';
import { Input, Button, Typography, Row, Col, Form, message } from 'antd';
import { UserOutlined, LockOutlined } from '@ant-design/icons'; 
import { useNavigate } from 'react-router-dom';

const { Title, Text } = Typography;

const Login = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    if (!username || !password) {
      message.error('Please enter both username and password!');
      return;
    }
    onLogin();
    navigate('/');
  };

  return (
    <div style={{ background: '#f0f2f5', minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <div style={{ background: '#fff', padding: '40px', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)', width: '100%', maxWidth: '400px' }}>
        <Title level={2} style={{ textAlign: 'center', color: '#333' }}>Login</Title>
        <Form onFinish={handleLogin}>
          <Form.Item
            name="username"
            rules={[{ required: true, message: 'Please input your username!' }]}
          >
            <Input
              prefix={<UserOutlined />}
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              style={{ marginBottom: '16px' }}
            />
          </Form.Item>

          <Form.Item
            name="password"
            rules={[{ required: true, message: 'Please input your password!' }]}
          >
            <Input.Password
              prefix={<LockOutlined />}
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={{ marginBottom: '16px' }}
            />
          </Form.Item>

          <Form.Item>
            <Button type="primary" htmlType="submit" block style={{ borderRadius: '8px', backgroundColor: '#1890ff', borderColor: '#1890ff' }}>
              Login
            </Button>
          </Form.Item>

          <Row justify="space-between">
            <Col>
              <Text style={{ color: '#1890ff', cursor: 'pointer' }} onClick={() => navigate('/forgot-password')}>
                Forgot Password?
              </Text>
            </Col>
            <Col>
              <Text style={{ color: '#1890ff', cursor: 'pointer' }} onClick={() => navigate('/register')}>
                Create Account
              </Text>
            </Col>
          </Row>
        </Form>
      </div>
    </div>
  );
};

export default Login;
