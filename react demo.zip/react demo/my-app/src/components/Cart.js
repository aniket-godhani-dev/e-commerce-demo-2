import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Button } from 'antd';
import { removeFromCart } from '../redux/actions';

const Cart = () => {
  const cart = useSelector((state) => state.cart);
  const dispatch = useDispatch();

  const handleRemoveFromCart = (productId) => {
    dispatch(removeFromCart(productId));
  };

  return (
    <div>
      <h1>Shopping Cart</h1>
      {cart.length === 0 ? (
        <p>Your cart is empty</p>
      ) : (
        cart.map((item) => (
          <div key={item.id} style={{ marginBottom: 10 }}>
            <h3>{item.name}</h3>
            <Button onClick={() => handleRemoveFromCart(item.id)} danger>
              Remove
            </Button>
          </div>
        ))
      )}
    </div>
  );
};

export default Cart;
