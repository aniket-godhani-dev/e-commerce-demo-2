import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Button } from 'antd';
import { removeFromWishlist } from '../redux/actions'; 

const Wishlist = () => {
  const wishlist = useSelector((state) => state.wishlist);
  const dispatch = useDispatch();

  const handleRemoveFromWishlist = (productId) => {
    dispatch(removeFromWishlist(productId));  
  };

  return (
    <div>
      <h1>Wishlist</h1>
      {wishlist.length === 0 ? (
        <p>Your wishlist is empty</p>
      ) : (
        wishlist.map((item) => (
          <div key={item.id} style={{ marginBottom: 10 }}>
            <h3>{item.name}</h3>
            <Button onClick={() => handleRemoveFromWishlist(item.id)} danger>
              Remove
            </Button>
          </div>
        ))
      )}
    </div>
  );
};

export default Wishlist;
