import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Badge, Menu, Layout, Typography, Modal, Input, Form, message } from 'antd';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCartOutlined, HeartOutlined, UserOutlined } from '@ant-design/icons';
import { loginUser } from '../redux/actions'; 

const { Header } = Layout;
const { Text } = Typography;

const HeaderComponent = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { isAuthenticated } = useSelector(state => state.user); 
  const cart = useSelector(state => state.cart);
  const wishlist = useSelector(state => state.wishlist);

  const [isModalVisible, setIsModalVisible] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogout = () => {
    
    dispatch({ type: 'LOGOUT' }); 
    navigate('/');
  };

  const handleLogin = () => {
  
    if (username && password) {
      
      dispatch(loginUser({ username, password }));
      setIsModalVisible(false); 
      navigate('/dashboard'); 
    } else {
      message.error('Please enter both username and password!');
    }
  };

  return (
    <>
      <Header style={{ position: 'sticky', top: 0, zIndex: 1000, backgroundColor: '#001529' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Link to="/" style={{ color: '#fff', fontSize: '24px', fontWeight: 'bold' }}>
            <Text style={{ color: '#fff' }}>MyStore</Text>
          </Link>

          <Menu mode="horizontal" theme="dark" style={{ flex: 1, justifyContent: 'center' }}>
            <Menu.Item key="home">
              <Link to="/" style={{ color: '#fff' }}>Home</Link>
            </Menu.Item>

            <Menu.Item key="cart" style={{ display: 'flex', alignItems: 'center' }}>
              <Link to="/cart" style={{ color: '#fff' }}>
                <Badge count={cart.length} style={{ backgroundColor: '#f5222d' }}>
                  <ShoppingCartOutlined style={{ fontSize: '20px', color: '#fff' }} />
                </Badge>
                <span style={{ marginLeft: '8px' }}>Cart</span>
              </Link>
            </Menu.Item>

            <Menu.Item key="wishlist" style={{ display: 'flex', alignItems: 'center' }}>
              <Link to="/wishlist" style={{ color: '#fff' }}>
                <Badge count={wishlist.length} style={{ backgroundColor: '#ff4d4f' }}>
                  <HeartOutlined style={{ fontSize: '20px', color: '#fff' }} />
                </Badge>
                <span style={{ marginLeft: '8px' }}>Wishlist</span>
              </Link>
            </Menu.Item>
          </Menu>

          <div style={{ display: 'flex', alignItems: 'center' }}>
            {isAuthenticated ? (
              <Button type="default" onClick={handleLogout} style={{ color: '#fff', borderColor: '#fff', marginRight: '16px' }}>
                Logout
              </Button>
            ) : (
              <Button type="default" onClick={() => setIsModalVisible(true)} style={{ color: '#fff', borderColor: '#fff' }}>
                <UserOutlined style={{ marginRight: '8px' }} />
                Login
              </Button>
            )}
          </div>
        </div>
      </Header>

      
      <Modal
        title="Login"
        visible={isModalVisible}
        onCancel={() => setIsModalVisible(false)}
        footer={null}
        destroyOnClose
      >
        <Form onFinish={handleLogin}>
          <Form.Item
            label="Username"
            required
            rules={[{ required: true, message: 'Please input your username!' }]}
          >
            <Input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your username"
            />
          </Form.Item>
          <Form.Item
            label="Password"
            required
            rules={[{ required: true, message: 'Please input your password!' }]}
          >
            <Input.Password
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
            />
          </Form.Item>
          <Button type="primary" htmlType="submit" block>
            Login
          </Button>
        </Form>
      </Modal>
    </>
  );
};

export default HeaderComponent;
