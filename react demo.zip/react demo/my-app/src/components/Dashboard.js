import React, { useState } from 'react';
import { Card, Button, Row, Col, Typography, Rate, Input, Form } from 'antd';
import { useDispatch } from 'react-redux';
import { addToCart, addToWishlist } from '../redux/actions';
import { ShoppingCartOutlined, HeartOutlined } from '@ant-design/icons';

const { Title, Text } = Typography;

const products = [
  { id: 1, name: 'Stylish Watch', price: 100, description: 'A beautiful and minimalist watch.', image: 'https://img.freepik.com/free-psd/watch-isolated-transparent-background_191095-27096.jpg?semt=ais_hybrid', rating: 4 },
  { id: 2, name: 'Leather Wallet', price: 200, description: 'High-quality leather wallet, sleek and stylish.', image: 'https://i5.walmartimages.com/asr/206fa744-ee08-4042-98be-c3b86e2db778_2.e1138c649a6a2befa715deff94613800.jpeg', rating: 5 },
  { id: 3, name: 'Bluetooth Headphones', price: 300, description: 'Wireless headphones with noise cancellation.', image: 'https://tse3.mm.bing.net/th?id=OIP.tyHXrA4EKA-ywTIgA9A6wAHaDt&pid=Api&P=0&h=180', rating: 4 },
];

const Dashboard = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false); 
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const dispatch = useDispatch();

  const handleAddToCart = (product) => {
    dispatch(addToCart(product));
  };

  const handleAddToWishlist = (product) => {
    dispatch(addToWishlist(product));
  };

  const handleLogin = () => {
    // Here, you can add real authentication logic
    if (username && password) {
      setIsLoggedIn(true); // Simulate login
    } else {
      alert('Please fill in both fields');
    }
  };

  if (!isLoggedIn) {
    return (
      <div style={{ textAlign: 'center', padding: '50px', maxWidth: '400px', margin: 'auto' }}>
        <Title level={2}>Login to View Dashboard</Title>
        <Form
          layout="vertical"
          onFinish={handleLogin}
          style={{
            background: '#fff',
            padding: '20px',
            borderRadius: '8px',
            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
          }}
        >
          <Form.Item
            label="Username"
            required
            rules={[{ required: true, message: 'Please input your username!' }]}
          >
            <Input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your username"
            />
          </Form.Item>
          <Form.Item
            label="Password"
            required
            rules={[{ required: true, message: 'Please input your password!' }]}
          >
            <Input.Password
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
            />
          </Form.Item>
          <Button type="primary" htmlType="submit" block>
            Login
          </Button>
        </Form>
      </div>
    );
  }

  return (
    <div style={{ padding: '40px', backgroundColor: '#f7f7f7' }}>
      <Title level={2} style={{ textAlign: 'center', color: '#333', marginBottom: '30px' }}>Product Dashboard</Title>
      <Row gutter={[16, 24]} justify="center">
        {products.map((product) => (
          <Col xs={24} sm={12} md={8} lg={6} key={product.id}>
            <Card
              hoverable
              style={{
                borderRadius: '16px',
                boxShadow: '0 8px 16px rgba(0, 0, 0, 0.1)',
                position: 'relative',
                transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
                overflow: 'hidden',
              }}
              cover={
                <div style={{
                  height: '200px',
                  backgroundImage: `url(${product.image})`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center',
                  transition: 'all 0.3s ease-in-out',
                  borderRadius: '16px 16px 0 0',
                }}></div>
              }
              onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.05)'}
              onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
            >
              <Card.Meta
                title={<Text strong>{product.name}</Text>}
                description={
                  <>
                    <Text type="secondary">{product.description}</Text>
                    <div style={{ marginTop: '10px' }}>
                      <Text strong>${product.price}</Text>
                    </div>
                    <div style={{ marginTop: '10px' }}>
                      <Rate disabled defaultValue={product.rating} />
                    </div>
                  </>
                }
              />
          
              <div style={{
                position: 'absolute',
                bottom: '0',
                left: '0',
                right: '0',
                padding: '12px',
                background: '#fff',
                borderRadius: '0 0 16px 16px',
                boxShadow: '0px -4px 12px rgba(0, 0, 0, 0.1)',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}>
                <Button
                  type="primary"
                  icon={<ShoppingCartOutlined />}
                  onClick={() => handleAddToCart(product)}
                  style={{
                    borderRadius: '8px',
                    width: '48%',
                    backgroundColor: '#1890ff',
                    borderColor: '#1890ff',
                    transition: 'background-color 0.3s ease-in-out',
                  }}
                  onMouseEnter={(e) => e.target.style.backgroundColor = '#40a9ff'}
                  onMouseLeave={(e) => e.target.style.backgroundColor = '#1890ff'}
                >
                  Add to Cart
                </Button>
                <Button
                  type="dashed"
                  icon={<HeartOutlined />}
                  onClick={() => handleAddToWishlist(product)}
                  style={{
                    borderRadius: '8px',
                    width: '48%',
                    color: '#ff4d4f',
                    borderColor: '#ff4d4f',
                    transition: 'border-color 0.3s ease-in-out, color 0.3s ease-in-out',
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.borderColor = '#ff7875';
                    e.target.style.color = '#ff7875';
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.borderColor = '#ff4d4f';
                    e.target.style.color = '#ff4d4f';
                  }}
                >
                  Add to Wishlist
                </Button>
              </div>
            </Card>
          </Col>
        ))}
      </Row>
    </div>
  );
};

export default Dashboard;
