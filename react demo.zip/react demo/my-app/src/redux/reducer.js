

import {
    LOGIN_USER,
    LOGOUT_USER,
    ADD_TO_CART,
    REMOVE_FROM_CART,
    ADD_TO_WISHLIST,
    REMOVE_FROM_WISHLIST
  } from './actions';
  
  const initialState = {
    user: localStorage.getItem('user') || null,
    cart: JSON.parse(localStorage.getItem('cart')) || [],
    wishlist: JSON.parse(localStorage.getItem('wishlist')) || [],
  };
  
  const reducer = (state = initialState, action) => {
    switch (action.type) {
      case LOGIN_USER:
        localStorage.setItem('user', 'loggedIn');
        return { ...state, user: 'loggedIn' };
      case LOGOUT_USER:
        localStorage.removeItem('user');
        return { ...state, user: null };
      case ADD_TO_CART:
        const updatedCart = [...state.cart, action.payload];
        localStorage.setItem('cart', JSON.stringify(updatedCart));
        return { ...state, cart: updatedCart };
      case REMOVE_FROM_CART:
        const filteredCart = state.cart.filter(item => item.id !== action.payload);
        localStorage.setItem('cart', JSON.stringify(filteredCart));
        return { ...state, cart: filteredCart };
      case ADD_TO_WISHLIST:
        const updatedWishlist = [...state.wishlist, action.payload];
        localStorage.setItem('wishlist', JSON.stringify(updatedWishlist));
        return { ...state, wishlist: updatedWishlist };
      case REMOVE_FROM_WISHLIST:
        const filteredWishlist = state.wishlist.filter(item => item.id !== action.payload);
        localStorage.setItem('wishlist', JSON.stringify(filteredWishlist));
        return { ...state, wishlist: filteredWishlist };
      default:
        return state;
    }
  };
  
  export default reducer;
  