import React from 'react';
import { Route, Routes, Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { loginUser, logoutUser } from './redux/actions';
import { Layout, Menu, Button } from 'antd';
import Dashboard from './components/Dashboard';
import Cart from './components/Cart';
import Wishlist from './components/Wishlist';
import Login from './components/Login';

const App = () => {
  const user = useSelector((state) => state.user);
  const dispatch = useDispatch();

  const handleLogin = () => {
    dispatch(loginUser());
  };

  const handleLogout = () => {
    dispatch(logoutUser());
  };

  return (
    <Layout>
      <Layout.Header>
        <Menu theme="dark" mode="horizontal">
          <Menu.Item key="1">
            <Link to="/">Home</Link>
          </Menu.Item>
          <Menu.Item key="2">
            <Link to="/cart">Cart</Link>
          </Menu.Item>
          <Menu.Item key="3">
            <Link to="/wishlist">Wishlist</Link>
          </Menu.Item>
          <Menu.Item key="4">
            {user ? (
              <Button onClick={handleLogout}>Logout</Button>
            ) : (
              <Link to="/login">
                <Button>Login</Button>
              </Link>
            )}
          </Menu.Item>
        </Menu>
      </Layout.Header>

      <Layout.Content style={{ padding: '20px' }}>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/wishlist" element={<Wishlist />} />
          <Route path="/login" element={<Login onLogin={handleLogin} />} />
        </Routes>
      </Layout.Content>
    </Layout>
  );
};

export default App;
